import socket,random,time

HOST = '127.0.0.1'  # The server's hostname or IP address
PORT = 1337        # The port used by the server

try:
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	print ("Socket successfully created")
except socket.error as err:
	print ("socket creation failed with error %s" %(err))
s.connect((HOST, PORT))
while(True):
    #random.randrange(5, 100, 5)
    time.sleep(.5)
    string_ = str(random.randint(10, 90))+","+str(random.randint(10, 90))
    print(string_)
    s.sendall(bytearray(string_.encode()))
s.close()
#data = s.recv(1024)
#print('Received', repr(data))