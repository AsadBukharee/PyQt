#!C:\Users\saabn\Desktop\ASSFHA\env\Scripts\python

import sys
import platform
import os,random
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import (QCoreApplication, QPropertyAnimation, QDate, QDateTime,
                          QMetaObject, QObject, QPoint, QRect, QSize, QTime, QUrl, Qt, QEvent)
from PyQt5.QtGui import (QBrush, QColor, QConicalGradient, QCursor, QFont, QFontDatabase,
                         QIcon, QKeySequence, QLinearGradient, QPalette, QPainter, QPixmap, QRadialGradient)
from PyQt5.QtWidgets import *
from PyQt5 import uic
import psutil
from pyqtgraph import PlotWidget
import pyqtgraph as pg
from pathlib import Path
import numpy as np
from collections import deque
import socket ,time
from _thread import *
import threading
from statistics import mean
from ui import Ui_MainWindow
from splash import Ui_SplashScreen
# GLOBALS
counter = 0
jumper = 10


class MainWindow(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        #self.ui = uic.loadUi("main.ui", self)
        #get system IP
        self.updateFlage=True
        self.ticks = int (self.ui.Ticks.text())
        self.ip_address = socket.gethostbyname(socket.gethostname())
        self.ui.IPInput.setText(self.ip_address)
        self.ui.PORT = int(self.ui.PortInput.text())
        self.print_lock = threading.Lock()
        print(self.ui.PORT)
        self.BreakServer = False#we want server to run initially
        self.meditation = 0
        self.attention = 0
        self.traces = dict()
        self.timestamp = 0
        self.timestamp_main = 0
        self.timeaxis = []
        self.cpuaxis = []
        self.ramaxis = []
        # self.csv_file = open(datafile, 'w')
        # self.csv_writer = csv.writer(self.csv_file, delimiter=',')
        self.current_timer_graph = None
        self.main_timer_graph = None
        self.graph_lim = int(self.ui.Ticks.text())

        self.deque_timestamp = deque([], maxlen=self.graph_lim+20)
        self.deque_meditation = deque([], maxlen=self.graph_lim+20)
        self.deque_attention = deque([], maxlen=self.graph_lim+20)

        self.deque_timestamp_main = deque([], maxlen=self.graph_lim+20)
        self.deque_meditation_main = deque([], maxlen=self.graph_lim+20)
        self.deque_attention_main = deque([], maxlen=self.graph_lim+20)
        # self.ui.label.setText(
        #     f"{platform.system()} {platform.machine()}")
        # self.ui.label_2.setText(
        #     f"Processor: {platform.processor()}")

        self.current_graph = PlotWidget(title="Current Values")
        self.current_graph.getPlotItem().addLegend()
        self.current_graph.getPlotItem().plot(name="attention", pen=pg.mkPen((255, 0,  127), width=2,style=QtCore.Qt.DotLine))
        self.current_graph.getPlotItem().plot(name="meditation",pen=pg.mkPen((85, 170, 255), width=2,style=QtCore.Qt.DotLine))
        x1_axis = self.current_graph.getAxis('bottom')
        x1_axis.setLabel(text='Last N Ticks')
        y1_axis = self.current_graph.getAxis('left')
        y1_axis.setLabel(text='Percent')

        self.main_graph = PlotWidget(title="Overall Values")
        self.main_graph.getPlotItem().addLegend()
        self.main_graph.getPlotItem().plot(name="attention",pen=pg.mkPen((255, 0, 127), width=2))
        self.main_graph.getPlotItem().plot(name="meditation",pen=pg.mkPen((85, 170, 255), width=2))
        x2_axis = self.main_graph.getAxis('bottom')
        x2_axis.setLabel(text='Time since start')
        y2_axis = self.main_graph.getAxis('left')
        y2_axis.setLabel(text='Percent')

        self.ui.MainGraphButton.clicked.connect(self.show_main_graph)
        self.ui.CurrentGraphButton.clicked.connect(self.show_current_graph)
        self.ui.ResetButton.clicked.connect(self.reset)
        self.ui.StopButton.clicked.connect(self.stop)
        self.ui.StartButton.clicked.connect(self.start)
        self.ui.ConnectButton.clicked.connect(self.networking)
        self.ui.DisconnectButton.clicked.connect(self.disconnect)



        self.ui.gridLayout.addWidget(self.current_graph, 0, 0, 1, 3)
        self.ui.gridLayout.addWidget(self.main_graph, 0, 0, 1, 3)
        #if you want the graphas to start automatically then uncomment folowing line
        #self.start()
        self.show_current_graph()
        # self.current_timer_systemStat = QtCore.QTimer()
        # self.current_timer_systemStat.timeout.connect(
        #     self.getsystemStatpercent)
        # self.current_timer_systemStat.start(1000)

        # self.network_timer = QtCore.QTimer()
        # self.network_timer.timeout.connect(self.networking)


        #self.show_current_graph()
#debug req#


    def stop(self):
        #stop all timers/threads
        print("stop action performed")
        self.stop_current_graph()
        self.stop_main_graph()
        self.updateFlage = False
        self.ui.StartButton.setEnabled(True)
        self.ui.StopButton.setEnabled(False)

    def start(self):
        print("start action performed")
        #start all timers/threads
        self.start_main_graph()
        self.start_current_graph()

        self.updateFlage = True
        self.ui.StartButton.setEnabled(False)
        self.ui.StopButton.setEnabled(True)

    def reset(self):
        print("Reset Clicked")
        self.ticks = int(self.ui.Ticks.text())
        self.deque_meditation= []
        self.deque_attention = []
        self.deque_timestamp = []
        self.current_graph.clear()
        self.stop()
        self.start()


    def disconnect(self):
        self.ui.BreakServer= not self.BreakServer
        if not self.BreakServer:
            self.ui.DisconnectButton.setText("Runing")
        else:
            self.ui.DisconnectButton.setText("Not Runing")
        self.ui.DisconnectButton.setEnabled(False)
        self.ui.ConnectButton.setEnabled(True)

    def server_threaded(self,conn):
        while True:
            data = conn.recv(10)
            if data:
                d = str(data.decode("utf-8"))
                s = d.split(',')
                if (len(s) >= 2):
                    print(s[0], " : ", s[1])
                    pass
                    # self.meditationLabel.setText(s[0]+"%")
                    # self.attentionLabel.setText(s[1]+"%")
                    # if you want the graphas to  update through network then uncomment folowing 2 lines and remove line 164 pass
                    #self.meditation= int(s[0])
                    #self.attention= int(s[1])

            if not data:
                self.print_lock.release()
                conn.close()
                break
            if self.BreakServer:
                self.print_lock.release()
                conn.close()
                break


    def networking(self):
        #I have disabled networking in this code you can call this method
        print("Connection Clicked")
        self.ui.DisconnectButton.setEnabled(True)
        self.ui.ConnectButton.setEnabled(False)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('', self.ui.PORT))
            s.listen()
            conn, addr = s.accept()
            self.ui.ClientIP.setText("connected to " + addr[0])
            self.print_lock.acquire()
            print('Connected to :', addr[0], ':', addr[1])
            # Start a new thread and return its identifier
            start_new_thread(self.server_threaded, (conn,))
            if self.BreakServer:
                s.close()

    def start_main_graph(self):
        # self.timeaxis = []
        # self.cpuaxis = []
        if self.main_timer_graph:
            self.main_timer_graph.stop()
            self.main_timer_graph.deleteLater()
            self.main_timer_graph = None
        self.main_timer_graph = QtCore.QTimer()
        self.main_timer_graph.timeout.connect(self.update_main)
        self.main_timer_graph.start(int(self.ui.FrequencyInputMain.text())*1000)


    def stop_main_graph(self):
        if self.main_timer_graph:
            self.main_timer_graph.stop()
            self.main_timer_graph.deleteLater()
            self.main_timer_graph = None

    def update_main(self):
        print("Main Updating")
        if self.updateFlage:
            self.timestamp_main += 1#int(self.FrequencyInputMain.text())
            # if len(self.deque_attention)==self.ticks:
            #     self.deque_meditation_main = []
            #     self.deque_attention_main  = []
            #     self.deque_timestamp_main  = []

            self.deque_timestamp_main.append(self.timestamp_main)
            self.deque_meditation_main.append(int(mean(list(self.deque_meditation))))
            self.deque_attention_main.append(int(mean(list(self.deque_attention))))


            timeaxis_list_m = list(self.deque_timestamp_main)
            meditation_m    = list(self.deque_meditation_main)
            attention_m     = list(self.deque_attention_main)

            if self.timestamp_main > self.graph_lim:
                self.main_graph.setRange(xRange=[self.timestamp_main-self.graph_lim+1, self.timestamp_main], yRange=[
                                           min(meditation_m[-self.graph_lim:]), max(meditation_m[-self.graph_lim:])])
            #print(timeaxis_list_m,meditation_m,attention_m)
            self.set_plotdata(self.main_graph,timeaxis_list_m,meditation_m,attention_m)

    def show_main_graph(self):
        self.current_graph.hide()
        self.main_graph.show()
        self.start_main_graph()
        self.ui.CurrentGraphButton.setEnabled(True)
        self.ui.MainGraphButton.setEnabled(False)
        # self.ui.CurrentGraphButton.setStyleSheet(
        #     "QCurrentGraphButton" "{" "background-color : lightblue;" "}"
        # )
        # self.ui.MainGraphButton.setStyleSheet(
        #     "QCurrentGraphButton"
        #     "{"
        #     "background-color : rgb(255, 44, 174);"
        #     "}"
        #     "QCurrentGraphButton"
        #     "{"
        #     "color : white;"
        #     "}"
        # )


    def start_current_graph(self):

        if self.current_timer_graph:
            self.current_timer_graph.stop()
            self.current_timer_graph.deleteLater()
            self.current_timer_graph = None
        self.current_timer_graph = QtCore.QTimer()
        self.current_timer_graph.timeout.connect(self.update_current)
        self.current_timer_graph.start(int(self.ui.FrequencyInputCurrent.text())*1000)

    def stop_current_graph(self):

        if self.current_timer_graph:
            self.current_timer_graph.stop()
            self.current_timer_graph.deleteLater()
            self.current_timer_graph = None


    def update_current(self):
        print("Current Updating")
        if self.updateFlage:
            self.timestamp += 1#t(self.FrequencyInputCurrent.text())
            if len(self.deque_attention)==self.ticks:
                self.deque_meditation = []
                self.deque_attention = []
                self.deque_timestamp = []
                self.current_graph.clear()
            #if you want to update these values from network, then disable followig line
            self.meditation,self.attention = int(random.randint(10, 90)) , int(random.randint(10, 90))
            self.deque_timestamp.append(self.timestamp)
            self.deque_meditation.append(self.meditation)
            self.deque_attention.append(self.attention)
            #update circular graphs
            self.setValue(int(self.meditation), self.ui.meditationLabel,
                          self.ui.circularProgressMeditation, "rgba(85, 170, 255, 255)")
            self.setValue(int(self.attention), self.ui.attentionLabel,
                          self.ui.circularProgressAttention, "rgba(255, 0, 127, 255)")

            timeaxis_list = list(self.deque_timestamp)
            meditation = list(self.deque_meditation)
            attention = list(self.deque_attention)

            # if self.timestamp > self.graph_lim:
            #     self.current_graph.setRange(xRange=[self.timestamp-self.graph_lim+1, self.timestamp], yRange=[
            #                                min(meditation[-self.graph_lim:]), max(meditation[-self.graph_lim:])])

            self.set_plotdata(self.current_graph,timeaxis_list,meditation,attention)

    def show_current_graph(self):
        self.main_graph.hide()
        self.current_graph.show()
        #self.current_graph.autoRange()
        self.start_current_graph()
        self.ui.MainGraphButton.setEnabled(True)
        self.ui.CurrentGraphButton.setEnabled(False)
        # self.ui.MainGraphButton.setStyleSheet(
        #     "QCurrentGraphButton" "{" "background-color : lightblue;" "}"
        # )
        # self.ui.CurrentGraphButton.setStyleSheet(
        #     "QCurrentGraphButton"
        #     "{"
        #     "background-color : rgba(85, 170, 255, 255);"
        #     "}"
        #     "QCurrentGraphButton"
        #     "{"
        #     "color : white;"
        #     "}"
        # )

    # def set_plotdata(self, name, data_x, data_y):
    #     # print('set_data')
    #     if name in self.traces:
    #         self.traces[name].setData(data_x, data_y)
    #     else:
    #         if name == "cpu":
    #             self.traces[name] = self.current_graph.getPlotItem().plot(
    #                 pen=pg.mkPen((85, 170, 255), width=3))
    #
    #         elif name == "ram":
    #             self.traces[name] = self.main_graph.getPlotItem().plot(
    #                 pen=pg.mkPen((255, 0, 127), width=3))

    def set_plotdata(self,graph, data_x,meditation,attention):# meditation,attention):
        # print('set_data')
        # self.main_graph.setBackground('w')
        graph.getPlotItem().plot(data_x,meditation,pen=pg.mkPen((85, 170, 255),width=3),  symbol='o', symbolSize=7, symbolBrush=('b'),fillLevel=1, fillBrush=(85,170,255,10))
        graph.getPlotItem().plot(data_x,attention, pen=pg.mkPen((255, 0, 127), width=3),  symbol='o', symbolSize=7, symbolBrush=('r'),fillLevel=1, fillBrush=(255,0,127,10))

    # ==> SET VALUES TO DEF progressBarValue

    def setValue(self, value, labelPercentage, progressBarName, color):

        sliderValue = value

        # HTML TEXT PERCENTAGE
        htmlText = """<p align="center"><span style=" font-size:30pt;">{VALUE}</span><span style=" font-size:20pt; vertical-align:super;">%</span></p>"""
        labelPercentage.setText(htmlText.replace(
            "{VALUE}", f"{sliderValue:.1f}"))

        # CALL DEF progressBarValue
        self.progressBarValue(sliderValue, progressBarName, color)

    # DEF PROGRESS BAR VALUE
    ########################################################################

    def progressBarValue(self, value, widget, color):

        # PROGRESSBAR STYLESHEET BASE
        styleSheet = """
        QFrame{
        	border-radius: 110px;
        	background-color: qconicalgradient(cx:0.5, cy:0.5, angle:90, stop:{STOP_1} rgba(255, 0, 127, 0), stop:{STOP_2} {COLOR});
        }
        """

        # GET PROGRESS BAR VALUE, CONVERT TO FLOAT AND INVERT VALUES
        # stop works of 1.000 to 0.000
        progress = (100 - value) / 100.0

        # GET NEW VALUES
        stop_1 = str(progress - 0.001)
        stop_2 = str(progress)

        # FIX MAX VALUE
        if value == 100:
            stop_1 = "1.000"
            stop_2 = "1.000"

        # SET VALUES TO NEW STYLESHEET
        newStylesheet = styleSheet.replace("{STOP_1}", stop_1).replace(
            "{STOP_2}", stop_2).replace("{COLOR}", color)

        # APPLY STYLESHEET WITH NEW VALUES
        widget.setStyleSheet(newStylesheet)


# ==> SPLASHSCREEN WINDOW
class SplashScreen(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.ui = Ui_SplashScreen()
        self.ui.setupUi(self)
        #self.ui = uic.loadUi("splash_screen.ui", self)
        # ==> SET INITIAL PROGRESS BAR TO (0) ZERO
        self.progressBarValue(0)

        # ==> REMOVE STANDARD TITLE BAR
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)  # Remove title bar
        # Set background to transparent
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

        # ==> APPLY DROP SHADOW EFFECT
        self.shadow = QGraphicsDropShadowEffect(self)
        self.shadow.setBlurRadius(20)
        self.shadow.setXOffset(0)
        self.shadow.setYOffset(0)
        self.shadow.setColor(QColor(0, 0, 0, 120))
        self.ui.circularBg.setGraphicsEffect(self.shadow)

        # QTIMER ==> START
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.progress)
        # TIMER IN MILLISECONDS
        self.timer.start(15)

        # SHOW ==> MAIN WINDOW
        ########################################################################
        self.show()
        ## ==> END ##

    # DEF TO LOANDING
    ########################################################################
    def progress(self):
        global counter
        global jumper
        value = counter

        # HTML TEXT PERCENTAGE
        htmlText = """<p><span style=" font-size:68pt;">{VALUE}</span><span style=" font-size:58pt; vertical-align:super;">%</span></p>"""

        # REPLACE VALUE
        newHtml = htmlText.replace("{VALUE}", str(jumper))

        if(value > jumper):
            # APPLY NEW PERCENTAGE TEXT
            self.ui.labelPercentage.setText(newHtml)
            jumper += 10

        # SET VALUE TO PROGRESS BAR
        # fix max value error if > than 100
        if value >= 100:
            value = 1.000
        self.progressBarValue(value)
        if counter == 10:
            self.main = MainWindow()

        # CLOSE SPLASH SCREE AND OPEN APP
        if counter > 100:
            # STOP TIMER
            self.timer.stop()

            # SHOW MAIN WINDOW
            # self.main = MainWindow()
            self.main.show()

            # CLOSE SPLASH SCREEN
            self.close()

        # INCREASE COUNTER
        counter += 0.5

    # DEF PROGRESS BAR VALUE
    ########################################################################
    def progressBarValue(self, value):

        # PROGRESSBAR STYLESHEET BASE
        styleSheet = """
        QFrame{
        	border-radius: 150px;
        	background-color: qconicalgradient(cx:0.5, cy:0.5, angle:90, stop:{STOP_1} rgba(255, 0, 127, 0), stop:{STOP_2} rgba(85, 170, 255, 255));
        }
        """

        # GET PROGRESS BAR VALUE, CONVERT TO FLOAT AND INVERT VALUES
        # stop works of 1.000 to 0.000
        progress = (100 - value) / 100.0

        # GET NEW VALUES
        stop_1 = str(progress - 0.001)
        stop_2 = str(progress)

        # SET VALUES TO NEW STYLESHEET
        newStylesheet = styleSheet.replace(
            "{STOP_1}", stop_1).replace("{STOP_2}", stop_2)

        # APPLY STYLESHEET WITH NEW VALUES
        self.ui.circularProgress.setStyleSheet(newStylesheet)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = SplashScreen()
    sys.exit(app.exec_())
